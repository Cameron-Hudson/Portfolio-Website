import java.util.Scanner;

/**
 * A class to represent a database which holds information on the user's desired plants
 * as well as methods to receive and record the plants from the user, displaying these plants
 * to the user, and being able to search this database for a certain plant by name.
 * 
 * @author Cameron Hudson
 * @version 1.0
 */

public class PlantSpeciesDatabase {

	public PlantSpecies[] plants;
	
	/**
     * Constructor that initialises the plant array with 5 default PlantSpecies objects.
     */
	public PlantSpeciesDatabase() {
		plants = new PlantSpecies[5];
		
		for (int i = 0; i < plants.length; i++) {
			plants[i] = new PlantSpecies();
		}
	}
	
	/**
     * Gets the plant information entered by the user.
     * @param scanner the Scanner object for detecting user input
     */
	public void getPlantInfo(Scanner scanner) {
		for (int i=0; i< plants.length; i++) {
		
		System.out.println("Please enter the species name of Plant" + (i+1));
		plants[i].setSpeciesName(scanner.nextLine());
		
		System.out.println("Please enter the region of Plant" + (i+1));
		plants[i].setRegion(scanner.nextLine());
		
		System.out.println("Please enter the leaf length of Plant" + (i+1));
		float leafLength = Float.parseFloat(scanner.nextLine());
		plants[i].setLeafLength(leafLength);
		
		System.out.println("Please enter the leaf width of Plant" + (i+1));
		float leafWidth = Float.parseFloat(scanner.nextLine());
		plants[i].setLeafWidth(leafWidth);
		
		}
	}
	
	/**
     * Displays the plant information entered by the user which is now in the database.
     */
	public void displayPlants() {
		for (int i=0; i< plants.length; i++) {
			String name = plants[i].getSpeciesName();
			String region = plants[i].getRegion();
			float leafLength = plants[i].getLeafLength();
			float leafWidth = plants[i].getLeafWidth();
			
			System.out.println("Plant" + i+1 + "| Name:" + name + "| Region:" + region + "| leafLength:" + leafLength + "| leafWidth:" + leafWidth);
		}
	}
	
	/**
     * Allows the user to search for a plant by name to see if there is one in the database.
     * @param scanner the Scanner object for detecting user input
     */
	public void searchPlants(Scanner scanner) {
		boolean found = false;
		System.out.println("Please enter the name of the plant you would like to search for: ");
		String nameToSearch = scanner.nextLine();
		for (int i=0; i< plants.length; i++) {
			if (plants[i].getSpeciesName().equalsIgnoreCase(nameToSearch)) {
				found = true;
				System.out.println("Plant found! Name:" + (plants[i].getSpeciesName()) + "| Region:" + (plants[i].getRegion()) + "| leafLength:" + (plants[i].getLeafLength()) + "| leafWidth:" + (plants[i].getLeafWidth()));
				break;
			}
		}
		
		if (found == false) {
			System.out.println("Plant not Found!");
			
		}
	}
}