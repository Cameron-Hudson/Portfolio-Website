import java.util.Scanner;

/**
 * A class to declare the variables that a plant in the database will be known by,
 * as well as get and set methods for each variable, a constructor which initalises
 * the variables with default values, and a main class to call all methods in the program.
 * 
 * @author Cameron Hudson
 * @version 1.0
 */

public class PlantSpecies {

	String speciesName;
	String region;
	float leafLength;
	float leafWidth;
	
	/**
     * Gets the species name.
     * @return the species name
     */
	public String getSpeciesName() {
		return speciesName;
	}
	
	/**
     * Sets the species name.
     * @param newSpeciesName the new species name
     */
	public void setSpeciesName(String newSpeciesName) {
		this.speciesName = newSpeciesName;
		
	}
	
	/**
     * Gets the region name.
     * @return the region name
     */
	public String getRegion() {
		return region;
	}
	
	/**
     * Sets the region for the plant.
     * @param region the region that the plant is found in
     */
	public void setRegion(String newRegion) {
		this.region = newRegion;
		
	}
	
	/**
     * Gets the leaf length.
     * @return the leaf length
     */
	public float getLeafLength() {
		return leafLength;
	}
	
	/**
     * Sets the leaf length.
     * @param leafLength the length of the plant's leaves
     */
	public void setLeafLength(float setLeafLength) {
		this.leafLength = setLeafLength;
		
	}
	
	/**
     * Gets the leaf width.
     * @return the leaf width
     */
	public float getLeafWidth() {
		return leafWidth;
	}
	
	/**
     * Sets the leaf width.
     * @param leafWidth the width of the plant's leaves
     */
	public void setLeafWidth(float setLeafWidth) {
		this.leafWidth = setLeafWidth;
		
	}
	
	/**
     * Constructor which initialises the variables to default values.
     */
	public PlantSpecies() {
		this.speciesName = null;
		this.region = null;
		this.leafLength = 0.0f;
		this.leafWidth = 0.0f;
	
	}
	
	/**
     * Constructor which initalises the variables.
     * @param speciesName the species name
     * @param region the region
     * @param leafLength the leaf length
     * @param leafWidth the leaf width
     */
	public PlantSpecies(String speciesName, String region, float leafLength, float leafWidth) {
		this.speciesName = speciesName;
		this.region = region;
		this.leafLength = leafLength;
		this.leafWidth = leafWidth;
	}
	
	/**
     * Main method to run the whole program.
     * @param args string arguments
     */
	public static void main(String[]args) {
		Scanner scanner = new Scanner(System.in);
		PlantSpeciesDatabase database = new PlantSpeciesDatabase();
		database.getPlantInfo(scanner);
		database.displayPlants();
		database.searchPlants(scanner);
		scanner.close();
	}
}