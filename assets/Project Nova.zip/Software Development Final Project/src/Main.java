public class Main {

	public static void main(String[] args) {
		Menu mainMenu = new Menu();
		
		try {
			mainMenu.displayMenu();
			
		} catch (Exception e) {
			System.out.println("Game Error");
			e.printStackTrace();
		}
	}
}
