import java.io.PrintWriter;
import java.util.Random;
import java.io.IOException;
public class Board {
	
	public void createGrids() {
		try {
			PrintWriter writer = new PrintWriter("game.txt");
			
			writer.println("PLAYER");
			writer.println("0");
			writer.println("0,0,0");
			
			char[][] userGrid = createGrid();
			saveGrid(writer, userGrid);
			
			char[][] displayGrid = createBlankGrid();
			saveGrid(writer, displayGrid);
			
			writer.println("COMPUTER");
			writer.println("0");
			writer.println("0,0,0");
			
			char[][] computerGrid = createGrid();
			saveGrid(writer, computerGrid);
			
			writer.close();
		} catch (IOException e) {
			System.out.println("Cannot create file: " + e.getMessage());
		}
	}
	
	private char[][] createGrid() {
		char[][] tempGrid = new char[8][8];
		for(int row=0; row<8; row++) {
			for(int column=0; column<8; column++) {
				tempGrid[row][column] = '~';
			}
		}
		placeCreatures(tempGrid, 'f', 1, 4);
		placeCreatures(tempGrid, 'c', 2, 1);
		placeCreatures(tempGrid, 't', 2, 1);
		placeCreatures(tempGrid, 's', 4, 1);
	
		return tempGrid;
	}
	private void placeCreatures(char[][] grid, char symbol, int size, int count) {
		Random pickRandom = new Random();
		int placedCount = 0;
		
		while (placedCount < count) {
			int row = pickRandom.nextInt(8);
			int column = pickRandom.nextInt(8 - size + 1);
			
			boolean safe = true;
			for (int i = 0; i < size; i++) {
				if (grid[row][column] != '~') {
					safe = false;
				}
			}
			
			if (safe) {
				for (int j = 0; j < size; j++) {
					grid[row][column + j] = symbol;
				}
				placedCount = (placedCount + 1);
			}
		}
	}
	
	private char[][] createBlankGrid() {
		char[][] displayGrid = new char[8][8];
		for (int r = 0; r< 8; r++) {
			for(int c = 0; c < 8; c++) {
				displayGrid[r][c] = '~';
			}
		}
		return displayGrid;
	}
	
	private void saveGrid(PrintWriter writer, char[][] grid) {
		for (int r = 0; r < 8; r++ ) {
			for (int c = 0; c < 8; c++) {
				writer.print(grid[r][c]);
			}
			writer.println();
		}
	}
}