import java.util.Scanner;
import java.util.Random;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;

public class Game {
	
	boolean gameRunning = true;
	
	char[][] playerSolutionGrid = new char[8][8];
	char[][] playerDisplayGrid = new char[8][8];
	int playerScore = 0;
	int playerCrabCount = 0;
	int playerTurtleCount = 0;
	int playerSharkCount = 0;
	
	char[][] computerSolutionGrid = new char[8][8];
	char[][] computerDisplayGrid = new char[8][8];
	int computerScore = 0;
	int computerCrabCount = 0;
	int computerTurtleCount = 0;
	int computerSharkCount = 0;
	
	int lastPickedRow = -1;
	int lastPickedColumn = -1;
	boolean hitLastTurn = false;
	Random randomPicker = new Random();
	
	Scanner input = new Scanner(System.in);

    public Game() {
        for (int r = 0; r < 8; r++) {
            for (int c = 0; c < 8; c++) {
                playerSolutionGrid[r][c] = '~';
                playerDisplayGrid[r][c] = '~';
                computerSolutionGrid[r][c] = '~';
                computerDisplayGrid[r][c] = '~';
            }
        }
    }
    
	public void loadGameFile() {
	        try {
	            File file = new File("game.txt");
	            Scanner fileReader = new Scanner(file);
	            
	            if(fileReader.hasNextLine()) fileReader.nextLine();

	            playerScore = Integer.parseInt(fileReader.nextLine());

	            String[] pParts = fileReader.nextLine().split(",");
	            playerCrabCount   = Integer.parseInt(pParts[0]);
	            playerTurtleCount = Integer.parseInt(pParts[1]);
	            playerSharkCount  = Integer.parseInt(pParts[2]);

	            fillGrid(fileReader, playerSolutionGrid);
	            fillGrid(fileReader, playerDisplayGrid);
	            
	            fileReader.nextLine();

	            computerScore = Integer.parseInt(fileReader.nextLine());

	            String[] cParts = fileReader.nextLine().split(",");
	            computerCrabCount   = Integer.parseInt(cParts[0]);
	            computerTurtleCount = Integer.parseInt(cParts[1]);
	            computerSharkCount  = Integer.parseInt(cParts[2]);

	            fillGrid(fileReader, computerSolutionGrid);
	            fillGrid(fileReader, computerDisplayGrid);

	            fileReader.close();
	            System.out.println("Game Loaded Successfully!");

	        } catch (FileNotFoundException e) {
	            System.out.println("Error: game.txt not found. Please start a new game first.");
	        }
		}
		
		private void fillGrid(Scanner reader, char[][] gridToFill) {
	        for (int r = 0; r < 8; r++) {
	            if (reader.hasNextLine()) {
	                String line = reader.nextLine();
	                for (int c = 0; c < 8; c++) {
	                    gridToFill[r][c] = line.charAt(c);
	                }
	            }
	        }
		}

	    public void playerTurn() {
	        System.out.println("\n--- YOUR TURN ---");

	        displayGrid(playerDisplayGrid);

	        System.out.println("'2' to Save your game file and Exit to the main menu or anything other number to make a guess: ");
	        int choice = input.nextInt();

	        if (choice == 2) {
	            saveAndExit();
	            return; 
	        }

	        System.out.println("Enter Row (0-7): ");
	        int row = input.nextInt();
	        
	        System.out.println("Enter Column (0-7): ");
	        int column = input.nextInt();

	        if (row < 0 || row > 7 || column < 0 || column > 7) {
	            System.out.println("Oh dear! you missed the map entirely, your turn will be skipped.");
	            return;
	        }

	        if (playerDisplayGrid[row][column] != '~') {
	            System.out.println("Oh dear! you already guessed there. your turn will be skipped.");
	            return;
	        }

	        char target = playerSolutionGrid[row][column];

	        if (target != '~') {
	            System.out.println("You hit a " + target + "! Congrats!");
	            
	            playerDisplayGrid[row][column] = target;
	            
	            playerScore = (playerScore + 1); 

	            if (target == 'c') {
	                playerCrabCount = (playerCrabCount + 1);
	                if (playerCrabCount == 2) System.out.println("You discovered the whole crab, you have earned 2 points!");
	            }
	            else if (target == 't') {
	            	playerTurtleCount = (playerTurtleCount + 1);
	                if (playerTurtleCount == 2) System.out.println("You discovered the whole turtle, you have earned 2 points!");
	            }
	            else if (target == 's') {
	            	playerSharkCount = (playerSharkCount + 1);
	                if (playerSharkCount == 4) System.out.println("You discovered the whole shark, you have earned 2 points!");
	            }

	        } else {
	            System.out.println("Unlucky, you didnt catch anything this time.");
	            playerDisplayGrid[row][column] = 'X';
	        }
	    }

	    public void displayGrid(char[][] grid) {
	        System.out.println("  0 1 2 3 4 5 6 7");
	        for (int r = 0; r < 8; r++) {
	            System.out.print(r + " ");
	            for (int c = 0; c < 8; c++) {
	                System.out.print(grid[r][c] + " ");
	            }
	            System.out.println();
	        }
	    }
	    
	    public void computerTurn() {
	        System.out.println("\n--- COMPUTER'S TURN ---");

	        int row = 0;
	        int column = 0;
	        boolean validGuess = false;

	        while (validGuess == false) {
	            
	            if (hitLastTurn) {
	                row = lastPickedRow + 1;
	                column = lastPickedColumn;

	                if (row > 7 || computerDisplayGrid[row][column] != '~' || playerSolutionGrid[row][column] == 'X') {
	                    hitLastTurn = false; 
	                    continue;
	                }
	            } else {
	                row = randomPicker.nextInt(8);
	                column = randomPicker.nextInt(8);
	            }

	            if (computerDisplayGrid[row][column] == '~') {
	                validGuess = true; 
	            }
	        }

	        char target = playerSolutionGrid[row][column];
	        System.out.println("The computer guessed: Row " + row + ", and Column " + column);

	        if (target != '~') {
	            System.out.println("The computer discovered " + target + "!");
	            
	            computerScore = (computerScore + 1);

	            if (target == 'c') computerCrabCount = (computerCrabCount + 1);
	            if (target == 't') computerTurtleCount = (computerTurtleCount + 1);
	            if (target == 's') computerSharkCount = (computerSharkCount + 1);

	            hitLastTurn = true; 
	            lastPickedRow = row;
	            lastPickedColumn = column;

	            computerDisplayGrid[row][column] = target;

	        } else {
	            System.out.println("The computer missed and hit the water!.");
	            
	            hitLastTurn = false;
	    
	            playerSolutionGrid[row][column] = 'X'; 
	        }
	        if (computerScore >= 12) {
	            System.out.println("GAME OVER: Computer WINS !!!!!!.");
	        }
	    }
	    
	    public void playGame() {
	        gameRunning = true;
	        
	        while (gameRunning == true) {
	            
	            playerTurn(); 
	            
	            if (gameRunning == false) {
	            	return;
	            }

	            if (playerScore >= 12) {
	                System.out.println("CONGRATULATIONS! You found all the creatures!");
	                break;
	            }

	            computerTurn();

	            if (computerScore >= 12) {
	                System.out.println("GAME OVER! The computer found all your creatures.");
	                break;
	            }
	        }
	    }

	    public void saveAndExit() {
	        try {
	            PrintWriter writer = new PrintWriter("game.txt");

	            writer.println("PLAYER");
	            writer.println(playerScore);
	            writer.println("0," + playerCrabCount + "," + playerTurtleCount + "," + playerSharkCount);
	            
	            saveGrid(writer, playerSolutionGrid);
	            saveGrid(writer, playerDisplayGrid);

	            writer.println("COMPUTER");
	            writer.println(computerScore);
	            writer.println("0," + computerCrabCount + "," + computerTurtleCount + "," + computerSharkCount);
	            
	            saveGrid(writer, computerSolutionGrid);
	            saveGrid(writer, computerDisplayGrid);

	            writer.close();
	            System.out.println("Game Saved! Returning to ther main menu.");

	            gameRunning = false; 

	        } catch (FileNotFoundException e) {
	            System.out.println("Error saving game.");
	        }
	    }

	    private void saveGrid(PrintWriter writer, char[][] grid) {
	        for (int r = 0; r < 8; r++) {
	            for (int c = 0; c < 8; c++) {
	                writer.print(grid[r][c]); 
	            }
	            writer.println();
	        }
	    }
}