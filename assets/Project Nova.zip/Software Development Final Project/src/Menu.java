import java.util.Scanner;
import java.io.FileNotFoundException;

public class Menu {
Scanner menuScanner = new Scanner(System.in);
boolean running = true;

public void displayMenu() throws FileNotFoundException {
    while (running) {
        
        System.out.println("\n--- MAIN MENU ---");
        System.out.println("1. Start a New Game");
        System.out.println("2. Load Game");
        System.out.println("3. Help");
        System.out.println("4. Exit");
        System.out.print("Enter choice: ");

        int menuChoice = 0;
        
        try {
            menuChoice = menuScanner.nextInt();
        } catch (Exception e) {
            menuScanner.nextLine(); 
            System.out.println("Please enter a number.");
            continue;
        }
	if (menuChoice == 1) {
		Board fileSetup = new Board();
		try {
	        fileSetup.createGrids(); 
	        
	        System.out.println("New game file created successfully.");
	        
	    } catch (Exception e) {
	        System.out.println("Error creating file.");
	    }
		
		Game myGame = new Game();
		myGame.loadGameFile();
		myGame.playGame();
	}
	else if (menuChoice == 2) {
		Game myGame = new Game();
		myGame.loadGameFile();
		myGame.playGame();
	}
	else if (menuChoice == 3) {
	}
	else if (menuChoice == 4) {
		running = false;
	}
	else {
		System.out.println("Please select between 1 and 4.");
	}
		}
	}
}